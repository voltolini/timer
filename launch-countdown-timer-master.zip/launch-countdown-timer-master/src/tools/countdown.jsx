const countdown = () => {
  const seconds = 60;
};

export default countdown;
